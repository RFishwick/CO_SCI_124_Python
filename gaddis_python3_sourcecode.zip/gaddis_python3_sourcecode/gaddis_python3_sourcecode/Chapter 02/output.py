print('Kate Austen')
print('123 Full Circle Drive')
print('Asheville, NC 28899')
